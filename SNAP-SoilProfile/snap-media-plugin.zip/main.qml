// Snap! Media - variant of opengisch/qfield-snap (GPL-2.0)
//
// One toolbar button opens a menu:
//   Photo - soil profile | Photo - soil site | Audio note | Raster map | INSPIRE namespace...
// Every new record gets, automatically:
//   inspireid_namespace = namespace defined for the project (asked at project start, max 20 chars)
//   inspireid_localid   = YYYYMMDDHHMMSS (local time of the capture)
// Photos are stored in DCIM/soilprofile/ or DCIM/soilsite/, named <localid>.<ext>.
// For audio and raster the form opens with mediatype pre-filled; use the Attachment widget
// of the "path" field to record or pick the file. Dictation (Vocal QField) can fill "notes".
//
// NOTE: not tested on a device yet. Try it on a test project first.
import QtQuick
import QtQuick.Controls
import org.qfield
import org.qgis
import Theme
import "qrc:/qml" as QFieldItems

Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property var positionSource: iface.findItemByObjectName('positionSource')
  property var dashBoard: iface.findItemByObjectName('dashBoard')
  property var overlayFeatureFormDrawer: iface.findItemByObjectName('overlayFeatureFormDrawer')

  // field names of the media layer (see make_media_gpkg.py)
  readonly property string fMediaType: 'mediatype'
  readonly property string fSubject: 'subject'
  readonly property string fPath: 'path'
  readonly property string fCapturedAt: 'captured_at'
  readonly property string fNamespace: 'inspireid_namespace'
  readonly property string fLocalId: 'inspireid_localid'
  readonly property var requiredFields: [fMediaType, fPath, fNamespace, fLocalId]

  readonly property int namespaceMaxLength: 20

  // namespace of the current project ('' = not defined yet)
  property string inspireNamespace: ''

  // choice made in the menu, kept for the asynchronous camera callback
  property string pendingSubject: ''

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(snapButton)
    startupCheck.start()
  }

  // ---- namespace persistence (per project, stored in the QField app settings) -------------
  function settingsKey() {
    return '/SnapMedia/namespace/' + String(qgisProject.homePath).replace(/[^A-Za-z0-9]/g, '_')
  }

  function loadNamespace() {
    plugin.inspireNamespace = String(settings.value(settingsKey(), ''))
    return plugin.inspireNamespace
  }

  function askNamespaceIfNeeded() {
    if (loadNamespace() === '') {
      nsDialog.open()
    }
  }

  // The plugin can be loaded before the project: check at load, again when a project finishes
  // loading, and again on every button tap, so the dialog cannot be skipped.
  Timer {
    id: startupCheck
    interval: 1500
    repeat: false
    onTriggered: plugin.askNamespaceIfNeeded()
  }

  Connections {
    target: iface
    function onLoadProjectEnded() {
      startupCheck.restart()
    }
  }

  Dialog {
    id: nsDialog
    parent: mainWindow.contentItem
    modal: true
    title: qsTr('INSPIRE namespace')
    standardButtons: Dialog.Ok | Dialog.Cancel
    width: Math.min(mainWindow.contentItem.width * 0.9, 420)
    x: (mainWindow.contentItem.width - width) / 2
    y: (mainWindow.contentItem.height - height) / 3

    onAboutToShow: nsField.text = plugin.inspireNamespace
    Component.onCompleted: standardButton(Dialog.Ok).enabled = Qt.binding(function() { return nsField.text.trim().length > 0 })

    onAccepted: {
      const ns = nsField.text.trim()
      if (ns.length === 0) {
        return
      }
      settings.setValue(plugin.settingsKey(), ns)
      plugin.inspireNamespace = ns
      mainWindow.displayToast(qsTr('INSPIRE namespace: %1').arg(ns))
    }

    contentItem: Column {
      spacing: 8
      Label {
        width: parent.width
        wrapMode: Text.WordWrap
        text: qsTr('Namespace assigned to every new record of this project (inspireid_namespace). Letters, digits, ".", "_" and "-", max %1 characters.').arg(plugin.namespaceMaxLength)
      }
      TextField {
        id: nsField
        width: parent.width
        maximumLength: plugin.namespaceMaxLength
        placeholderText: qsTr('e.g. IT.MYORG.SOIL')
        inputMethodHints: Qt.ImhNoPredictiveText | Qt.ImhPreferUppercase
        validator: RegularExpressionValidator { regularExpression: /[A-Za-z0-9._-]*/ }
      }
      Label {
        width: parent.width
        horizontalAlignment: Text.AlignRight
        text: nsField.text.length + ' / ' + plugin.namespaceMaxLength
      }
    }
  }

  // ---- camera ----------------------------------------------------------------------------
  Loader {
    id: cameraLoader
    active: false
    sourceComponent: Component {
      id: cameraComponent
      QFieldItems.QFieldCamera {
        id: qfieldCamera
        visible: false

        Component.onCompleted: {
          open()
        }
        onFinished: (path) => {
          close()
          plugin.snap(path)
        }
        onCanceled: {
          close()
        }
        onClosed: {
          cameraLoader.active = false
        }
      }
    }
  }

  // ---- menu and button -------------------------------------------------------------------
  Menu {
    id: typeMenu
    title: qsTr('New media')

    MenuItem {
      text: qsTr('Photo - soil profile')
      onTriggered: plugin.startPhoto('soilprofile')
    }
    MenuItem {
      text: qsTr('Photo - soil site')
      onTriggered: plugin.startPhoto('soilsite')
    }
    MenuItem {
      text: qsTr('Audio note')
      onTriggered: plugin.newRecord('audio', '', '')
    }
    MenuItem {
      text: qsTr('Raster map')
      onTriggered: plugin.newRecord('raster', '', '')
    }
    MenuSeparator {}
    MenuItem {
      text: qsTr('INSPIRE namespace...')
      onTriggered: {
        plugin.loadNamespace()
        nsDialog.open()
      }
    }
  }

  QfToolButton {
    id: snapButton
    bgcolor: Theme.darkGray
    iconSource: Theme.getThemeVectorIcon('ic_camera_photo_black_24dp')
    iconColor: Theme.mainColor
    round: true

    onClicked: {
      if (plugin.loadNamespace() === '') {
        nsDialog.open()
        return
      }
      typeMenu.popup()
    }
  }

  // ---- logic -----------------------------------------------------------------------------
  function stamp() {
    const d = new Date()
    return d.getFullYear().toString()
        + (d.getMonth() + 1).toString().padStart(2, '0')
        + d.getDate().toString().padStart(2, '0')
        + d.getHours().toString().padStart(2, '0')
        + d.getMinutes().toString().padStart(2, '0')
        + d.getSeconds().toString().padStart(2, '0')
  }

  function isoNow() {
    const d = new Date()
    return d.getFullYear() + '-' + (d.getMonth() + 1).toString().padStart(2, '0') + '-' + d.getDate().toString().padStart(2, '0')
        + 'T' + d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0') + ':' + d.getSeconds().toString().padStart(2, '0')
  }

  // returns true when the active layer and the GPS fix allow creating a record
  function checkReady() {
    dashBoard.ensureEditableLayerSelected()

    if (!positionSource.active || !positionSource.positionInformation.latitudeValid || !positionSource.positionInformation.longitudeValid) {
      mainWindow.displayToast(qsTr('Snap requires positioning to be active and returning a valid position'))
      return false
    }
    if (dashBoard.activeLayer.geometryType() != Qgis.GeometryType.Point) {
      mainWindow.displayToast(qsTr('Snap requires the active vector layer to be a point layer'))
      return false
    }
    const names = dashBoard.activeLayer.fields.names
    for (const f of plugin.requiredFields) {
      if (names.indexOf(f) < 0) {
        mainWindow.displayToast(qsTr('The active layer needs the field "%1" (use the media layer of media.gpkg)').arg(f))
        return false
      }
    }
    return true
  }

  function startPhoto(subject) {
    if (!checkReady()) {
      return
    }
    plugin.pendingSubject = subject
    platformUtilities.createDir(qgisProject.homePath, 'DCIM')
    platformUtilities.createDir(qgisProject.homePath + '/DCIM', subject)
    cameraLoader.active = true
  }

  // called when the camera returns a picture
  function snap(path) {
    const localId = stamp()
    const relativePath = 'DCIM/' + plugin.pendingSubject + '/' + localId + '.' + FileUtils.fileSuffix(path)
    platformUtilities.renameFile(path, qgisProject.homePath + '/' + relativePath)
    createRecord('photo', plugin.pendingSubject, relativePath, localId)
  }

  // audio / raster: the file is attached from the form, so no path yet
  function newRecord(mediatype, subject, relativePath) {
    if (plugin.loadNamespace() === '') {
      nsDialog.open()
      return
    }
    if (!checkReady()) {
      return
    }
    createRecord(mediatype, subject, relativePath, stamp())
  }

  function createRecord(mediatype, subject, relativePath, localId) {
    const pos = GeometryUtils.reprojectPoint(positionSource.projectedPosition, positionSource.coordinateTransformer.destinationCrs, dashBoard.activeLayer.crs);
    const elevation = positionSource.positionInformation.elevation;

    let wkt = '';
    switch (dashBoard.activeLayer.wkbType()) {
    case Qgis.WkbType.MultiPointZ:
      wkt = 'MULTIPOINTZ((' + pos.x + ' ' + pos.y + ' ' + elevation + '))';
      break;
    case Qgis.WkbType.MultiPointM:
      wkt = 'MULTIPOINTM((' + pos.x + ' ' + pos.y + ' 0 ))';
      break;
    case Qgis.WkbType.MultiPointZM:
      wkt = 'MULTIPOINTZM((' + pos.x + ' ' + pos.y + ' ' + elevation + ' 0))';
      break;
    case Qgis.WkbType.MultiPoint:
      wkt = 'MULTIPOINT((' + pos.x + ' ' + pos.y + '))';
      break;
    case Qgis.WkbType.PointZ:
      wkt = 'POINTZ(' + pos.x + ' ' + pos.y + ' ' + elevation + ')';
      break;
    case Qgis.WkbType.PointM:
      wkt = 'POINTM(' + pos.x + ' ' + pos.y + ' 0 )';
      break;
    case Qgis.WkbType.PointZM:
      wkt = 'POINTZM(' + pos.x + ' ' + pos.y + ' ' + elevation + ' 0)';
      break;
    case Qgis.WkbType.Point:
      wkt = 'POINT(' + pos.x + ' ' + pos.y + ')';
      break;
    default:
    }

    let geometry = GeometryUtils.createGeometryFromWkt(wkt)
    let feature = FeatureUtils.createBlankFeature(dashBoard.activeLayer.fields, geometry)
    const names = feature.fields.names

    function put(field, value) {
      const i = names.indexOf(field)
      if (i > -1 && value !== '') {
        feature.setAttribute(i, value)
      }
    }

    put(plugin.fMediaType, mediatype)
    put(plugin.fSubject, subject)
    put(plugin.fPath, relativePath)
    put(plugin.fNamespace, plugin.inspireNamespace)
    put(plugin.fLocalId, localId)
    put(plugin.fCapturedAt, isoNow())

    overlayFeatureFormDrawer.featureModel.feature = feature
    overlayFeatureFormDrawer.featureModel.resetAttributes(true)
    overlayFeatureFormDrawer.state = 'Add'
    overlayFeatureFormDrawer.open()
  }
}
